﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            outputTextBox.Text = "Delegate me!!";

        }

        

        public void EatMeBtn_Click(object sender, EventArgs e)
        {
            Color myColor = Color.Red;
            outputTextBox.BackColor = myColor;
            outputTextBox.Refresh();
            Thread.Sleep(500);

            Thread myThread = new Thread((ThreadStart)delegate { myColor = Color.Blue; });
            myThread.Start();
            Thread.Sleep(2);
            outputTextBox.BackColor = myColor;
            outputTextBox.Refresh();
        }

        private void DrinkMeBtn_Click(object sender, EventArgs e)
        {
            Color[] myColor = new Color[1] { Color.Red }; 
            outputTextBox.BackColor = myColor[0];
            outputTextBox.Refresh();
            Thread.Sleep(500);

            Thread myThread = new Thread((ParameterizedThreadStart) myMethod);
            myThread.Start(myColor); // a list is transfered into the method. a parameter is duplicated
            Thread.Sleep(20);
            outputTextBox.BackColor = myColor[0];
            outputTextBox.Refresh();
        }

        private void myMethod(object obj)
        {
            Color[] mymycolor = (Color[])obj;
            mymycolor[0] = Color.Black;
        }
    }
}
