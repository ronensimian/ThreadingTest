﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.outputTextBox = new System.Windows.Forms.TextBox();
            this.outputLabel = new System.Windows.Forms.Label();
            this.EatMeBtn = new System.Windows.Forms.Button();
            this.DrinkMeBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // outputTextBox
            // 
            this.outputTextBox.Location = new System.Drawing.Point(12, 48);
            this.outputTextBox.Multiline = true;
            this.outputTextBox.Name = "outputTextBox";
            this.outputTextBox.Size = new System.Drawing.Size(330, 89);
            this.outputTextBox.TabIndex = 0;
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.Location = new System.Drawing.Point(13, 29);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(42, 13);
            this.outputLabel.TabIndex = 1;
            this.outputLabel.Text = "Output:";
            // 
            // EatMeBtn
            // 
            this.EatMeBtn.Location = new System.Drawing.Point(12, 183);
            this.EatMeBtn.Name = "EatMeBtn";
            this.EatMeBtn.Size = new System.Drawing.Size(75, 23);
            this.EatMeBtn.TabIndex = 2;
            this.EatMeBtn.Text = "Eat Me";
            this.EatMeBtn.UseVisualStyleBackColor = true;
            this.EatMeBtn.Click += new System.EventHandler(this.EatMeBtn_Click);
            // 
            // DrinkMeBtn
            // 
            this.DrinkMeBtn.Location = new System.Drawing.Point(267, 183);
            this.DrinkMeBtn.Name = "DrinkMeBtn";
            this.DrinkMeBtn.Size = new System.Drawing.Size(75, 23);
            this.DrinkMeBtn.TabIndex = 3;
            this.DrinkMeBtn.Text = "Drink Me";
            this.DrinkMeBtn.UseVisualStyleBackColor = true;
            this.DrinkMeBtn.Click += new System.EventHandler(this.DrinkMeBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.DrinkMeBtn);
            this.Controls.Add(this.EatMeBtn);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.outputTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox outputTextBox;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Button EatMeBtn;
        private System.Windows.Forms.Button DrinkMeBtn;
    }
}

